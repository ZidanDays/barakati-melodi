

<?php $__env->startSection('content'); ?>
    <h2>Posts</h2>
    <a href="<?php echo e(route('posts.create')); ?>">Create New Post</a>

    <?php if($message = Session::get('success')): ?>
        <div><?php echo e($message); ?></div>
    <?php endif; ?>

    <table>
        <tr>
            <th>Title</th>
            <th>Content</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->content); ?></td>
            <td>
                <a href="<?php echo e(route('posts.show', $post->id)); ?>">Show</a>
                <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit</a>
                <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\barakativ2\resources\views/posts/index.blade.php ENDPATH**/ ?>